document.addEventListener('DOMContentLoaded', () => {  
    fetchPasswords(); // Load passwords on page load  

    // Set up event listener for form submission  
    document.getElementById('passwordForm').addEventListener('submit', function(e) {  
        e.preventDefault(); // Prevent default form submission  
        addPassword(); // Call the addPassword function  
    });  

    // Set up event listener for logout button  
    document.getElementById('logoutButton').addEventListener('click', logout); // Attach logout function  
});  

// Fetch existing passwords  
function fetchPasswords() {  
    fetch('backend/password_manager.php', {  
        method: 'GET',  
        headers: {  
            'Content-Type': 'application/json'  
        }  
    })  
    .then(response => {  
        if (!response.ok) {  
            throw new Error('Network response was not ok');  
        }  
        return response.json();  
    })  
    .then(passwords => {  
        updatePasswordsTable(passwords); // Call to update the UI with the fetched passwords  
    })  
    .catch(error => console.error('Error fetching passwords:', error));  
}  

// Update the password table in the UI  
function updatePasswordsTable(passwords) {  
    const passwordsDiv = document.getElementById('passwords');  
    passwordsDiv.innerHTML = ''; // Clear existing entries  

    // Check if passwords array is empty to provide feedback  
    if (passwords.length === 0) {  
        const noPasswordsMessage = document.createElement('tr');  
        noPasswordsMessage.innerHTML = `<td colspan="4">No saved passwords found.</td>`;  
        passwordsDiv.appendChild(noPasswordsMessage);  
        return;  // Exit if there are no passwords to show  
    }  

    // Loop through each password and create a table row  
    passwords.forEach(password => {  
        const row = document.createElement('tr');   
        row.innerHTML = `  
            <td>${password.website}</td>  
            <td>${password.username}</td>  
            <td>  
                <button onclick="decryptPassword('${password.encrypted_password}', '${password.iv}')">View Password</button>  
            </td>  
            <td>  
                <button onclick="editPassword(${password.id}, '${password.website}', '${password.username}')">Edit</button>  
                <button onclick="deletePassword(${password.id})">Delete</button>  
            </td>  
        `;  
        passwordsDiv.appendChild(row); // Append the row to the table  
    });  
}  

// Add a new password  
function addPassword() {  
    const formData = new FormData(document.getElementById('passwordForm')); // Gather form data  
    fetch('backend/password_manager.php', {  
        method: 'POST',  
        body: formData  
    })  
    .then(response => {  
        if (response.ok) {  
            alert('Password added successfully!');   
            fetchPasswords(); // Refresh the password table  
            document.getElementById('passwordForm').reset(); // Reset the form fields  
        } else {  
            alert('Failed to add password');  
        }  
    })  
    .catch(error => console.error('Error adding password:', error));  
}  

// Function to handle editing a password  
function editPassword(id, website, username) {  
    document.getElementById('website').value = website;  
    document.getElementById('username').value = username;  
    document.getElementById('password').value = ''; // Clear the password field for editing  

    // Change the submit handler to update the password  
    const form = document.getElementById('passwordForm');  
    form.onsubmit = function(e) {  
        e.preventDefault();   
        updatePassword(id); // Call the update function  
    };  
}  

// Update password function  
function updatePassword(id) {  
    const formData = new FormData(document.getElementById('passwordForm')); // Gather form data  
    fetch('backend/password_manager.php?id=' + id, {  
        method: 'PUT',  
        body: formData  
    })  
    .then(response => {  
        if (response.ok) {  
            alert('Password updated successfully!');   
            fetchPasswords(); // Refresh the password table  
            document.getElementById('passwordForm').reset(); // Reset the form fields  
        } else {  
            alert('Failed to update password');  
        }  
    })  
    .catch(error => console.error('Error updating password:', error));  
}  

// Function to handle deleting a password  
function deletePassword(id) {  
    if (confirm('Are you sure you want to delete this password?')) {  
        fetch('backend/password_manager.php?id=' + id, {  
            method: 'DELETE'  
        })  
        .then(response => {  
            if (response.ok) {  
                alert('Password deleted successfully!');   
                fetchPasswords(); // Refresh the password table  
            } else {  
                alert('Failed to delete password');  
            }  
        })  
        .catch(error => console.error('Error deleting password:', error));  
    }  
}  

// Function to handle logout  
function logout() {  
    fetch('backend/logout.php', { // Assume you have a logout endpoint  
        method: 'POST',  
        headers: {  
            'Content-Type': 'application/json'  
        }  
    })  
    .then(response => {  
        if (response.ok) {  
            alert('Logged out successfully!'); // Notify user  
            window.location.href = 'login.html'; // Redirect to login page  
        } else {  
            alert('Logout failed. Please try again.');  
        }  
    })  
    .catch(error => console.error('Error logging out:', error));  
}  

// Function to handle decrypting and showing the password (placeholder)  
function decryptPassword(encryptedPassword, iv) {  
    alert('Decryption is not implemented in the frontend for security.');  
}