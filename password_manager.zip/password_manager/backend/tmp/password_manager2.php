<?php  
session_start();  
include 'config.php';  

// Load Composer's autoloader  
require '../vendor/autoload.php';  // Adjust path as necessary  

// Load the dotenv file  
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../');  
$dotenv->load();  

// Access the encryption key  
$key = getenv('ENCRYPTION_KEY');  
if ($key === false) {  
    throw new Exception('Encryption key not found in environment variables.');  
}  

// Check user session  
if (!isset($_SESSION['user_id'])) {  
    header("Location: ../login.html");  
    exit();  
}  

// Function to encrypt data  
function encrypt($data) {  
    global $key; // Access the encryption key  
    // Generate an initialization vector  
    $iv_length = openssl_cipher_iv_length('aes-256-cbc');  
    $iv = openssl_random_pseudo_bytes($iv_length);  
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, 0, $iv);  

    // Prepend the IV to the encrypted data for later use in decryption  
    return base64_encode($iv . $encrypted);  
}  

// Function to decrypt data  
function decrypt($data) {  
    global $key; // Access the encryption key  
    // Decode the base64-encoded data  
    $data = base64_decode($data);  
    $iv_length = openssl_cipher_iv_length('aes-256-cbc');  
    $iv = substr($data, 0, $iv_length); // Get the IV from the start of the data  
    $encrypted = substr($data, $iv_length); // Get the encrypted data  

    // Decrypt the data  
    return openssl_decrypt($encrypted, 'aes-256-cbc', $key, 0, $iv);  
}  

// Handle POST, PUT, DELETE requests  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // Add Password  
    $user_id = $_SESSION['user_id'];  
    $website = $_POST['website'];  
    $username = $_POST['username'];  
    $password = $_POST['password'];  

    // Encrypt Password  
    $encrypted_password = encrypt($password);  

    $sql = "INSERT INTO passwords (user_id, website, username, encrypted_password) VALUES ('$user_id', '$website', '$username', '$encrypted_password')";  
    $conn->query($sql);  
} elseif ($_SERVER["REQUEST_METHOD"] == "PUT" || $_SERVER["REQUEST_METHOD"] == "DELETE") {  
    parse_str(file_get_contents("php://input"), $_PUT); // For PUT request  
    $user_id = $_SESSION['user_id'];  

    if ($_SERVER["REQUEST_METHOD"] == "PUT") {  
        // Update Password  
        $id = $_GET['id'];  
        $website = $_PUT['website'];  
        $username = $_PUT['username'];  
        $password = $_PUT['password'];  

        $encrypted_password = encrypt($password);  

        $sql = "UPDATE passwords SET website='$website', username='$username', encrypted_password='$encrypted_password' WHERE id='$id' AND user_id='$user_id'";  
        $conn->query($sql);  
    } elseif ($_SERVER["REQUEST_METHOD"] == "DELETE") {  
        // Delete Password  
        $id = $_GET['id'];  
        $sql = "DELETE FROM passwords WHERE id='$id' AND user_id='$user_id'";  
        $conn->query($sql);  
    }  
}  

// Fetch User Passwords  
$user_id = $_SESSION['user_id'];  
$sql = "SELECT * FROM passwords WHERE user_id='$user_id'";  
$result = $conn->query($sql);  

$passwords = [];  
while ($row = $result->fetch_assoc()) {  
    $passwords[] = $row;  
}  

$conn->close();  

// Output the passwords as JSON  
echo json_encode($passwords);