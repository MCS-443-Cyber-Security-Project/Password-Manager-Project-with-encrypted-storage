<?php  
session_start();  
include 'config.php';  

if (!isset($_SESSION['user_id'])) {  
    header("Location: ../login.html");  
    exit();  
}  

// Load required encryption key  
$key = getenv('ENCRYPTION_KEY'); // Make sure this is set in your .env file.  

if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // Add Password  
    $user_id = $_SESSION['user_id'];  
    $website = $_POST['website'];  
    $username = $_POST['username'];  
    $password = $_POST['password'];  

    // Encrypt Password with OpenSSL  
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc')); // Generate a new IV  
    $encrypted_password = openssl_encrypt($password, 'aes-256-cbc', $key, 0, $iv);  

    // Store the IV alongside the encrypted password  
    $sql = "INSERT INTO passwords (user_id, website, username, encrypted_password, iv) VALUES ('$user_id', '$website', '$username', '$encrypted_password', '".base64_encode($iv)."')";  
    $conn->query($sql);  
} elseif ($_SERVER["REQUEST_METHOD"] == "PUT" || $_SERVER["REQUEST_METHOD"] == "DELETE") {  
    parse_str(file_get_contents("php://input"), $_PUT); // For PUT request  
    $user_id = $_SESSION['user_id'];  

    if ($_SERVER["REQUEST_METHOD"] == "PUT") {  
        // Update Password  
        $id = $_GET['id'];  
        $website = $_PUT['website'];  
        $username = $_PUT['username'];  
        $password = $_PUT['password'];  
        
        // Encrypt Password with OpenSSL  
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));   
        $encrypted_password = openssl_encrypt($password, 'aes-256-cbc', $key, 0, $iv);  
        
        $sql = "UPDATE passwords SET website='$website', username='$username', encrypted_password='$encrypted_password', iv='".base64_encode($iv)."' WHERE id='$id' AND user_id='$user_id'";  
        $conn->query($sql);  
    } elseif ($_SERVER["REQUEST_METHOD"] == "DELETE") {  
        // Delete Password  
        $id = $_GET['id'];  
        $sql = "DELETE FROM passwords WHERE id='$id' AND user_id='$user_id'";  
        $conn->query($sql);  
    }  
}  

// Fetch User Passwords  
$user_id = $_SESSION['user_id'];  
$sql = "SELECT * FROM passwords WHERE user_id='$user_id'";  
$result = $conn->query($sql);  

$passwords = [];  
while ($row = $result->fetch_assoc()) {  
    // For each returned password, you can include the decryption key and IV  
    $row['iv'] = base64_decode($row['iv']); // Decode the IV  
    $passwords[] = $row;  
}  

$conn->close();  
echo json_encode($passwords);