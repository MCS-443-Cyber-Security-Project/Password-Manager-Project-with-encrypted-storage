<?php  
session_start();  
include 'config.php';  

if (!isset($_SESSION['user_id'])) {  
    header("Location: ../login.html");  
    exit();  
}  

// Load required encryption key  
$key = hash('sha256', getenv('ENCRYPTION_KEY')); // Use a hashed version of the key  

if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // Add Password  
    $user_id = $_SESSION['user_id'];  
    $website = $_POST['website'];  
    $username = $_POST['username'];  
    $password = $_POST['password'];  

    // Encrypt Password with OpenSSL  
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc')); // Generate a new IV  
    $encrypted_password = openssl_encrypt($password, 'aes-256-cbc', $key, 0, $iv);  

    // Store the IV alongside the encrypted password  
    $sql = "INSERT INTO passwords (user_id, website, username, encrypted_password, iv) VALUES ('$user_id', '$website', '$username', '$encrypted_password', '".base64_encode($iv)."')";  
    if ($conn->query($sql)) {  
        http_response_code(201); // Return a 201 Created status code  
    } else {  
        http_response_code(500); // Return a 500 Internal Server Error status code  
        error_log('Error adding password: ' . $conn->error);  
    }  
} elseif ($_SERVER["REQUEST_METHOD"] == "PUT" || $_SERVER["REQUEST_METHOD"] == "DELETE") {  
    parse_str(file_get_contents("php://input"), $_PUT); // For PUT request  
    $user_id = $_SESSION['user_id'];  

    if ($_SERVER["REQUEST_METHOD"] == "PUT") {  
        // Update Password  
        $id = $_GET['id'];  
        $website = $_PUT['website'];  
        $username = $_PUT['username'];  
        $password = $_PUT['password'];  

        // Encrypt Password with OpenSSL  
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));  
        $encrypted_password = openssl_encrypt($password, 'aes-256-cbc', $key, 0, $iv);  

        $sql = "UPDATE passwords SET website='$website', username='$username', encrypted_password='$encrypted_password', iv='".base64_encode($iv)."' WHERE id='$id' AND user_id='$user_id'";  
        if ($conn->query($sql)) {  
            http_response_code(200); // Return a 200 OK status code  
        } else {  
            http_response_code(500); // Return a 500 Internal Server Error status code  
            error_log('Error updating password: ' . $conn->error);  
        }  
    } elseif ($_SERVER["REQUEST_METHOD"] == "DELETE") {  
        // Delete Password  
        $id = $_GET['id'];  
        $sql = "DELETE FROM passwords WHERE id='$id' AND user_id='$user_id'";  
        if ($conn->query($sql)) {  
            http_response_code(204); // Return a 204 No Content status code  
        } else {  
            http_response_code(500); // Return a 500 Internal Server Error status code  
            error_log('Error deleting password: ' . $conn->error);  
        }  
    }  
}  

// Fetch User Passwords  
$user_id = $_SESSION['user_id'];  
$sql = "SELECT * FROM passwords WHERE user_id='$user_id'";  
$result = $conn->query($sql);  

if ($result->num_rows > 0) {  
    $passwords = [];  
    while ($row = $result->fetch_assoc()) {  
        // Just append the row without decrypting the password  
        $passwords[] = $row;  
    }  
    http_response_code(200); // Return a 200 OK status code  
    echo json_encode($passwords);  
} else {  
    http_response_code(404); // Return a 404 Not Found status code  
    echo json_encode(['error' => 'No passwords found']);  
}  

$conn->close();  
?>