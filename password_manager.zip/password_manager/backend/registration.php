<?php  
include 'config.php';  

if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    $username = $_POST['username'];  
    $email = $_POST['email'];  
    $password = $_POST['password']; // Get the raw password  
    $confirm_password = $_POST['confirm-password']; // Get confirm password  

    // Check if passwords match  
    if ($password !== $confirm_password) {  
        die("Passwords do not match.");  
    }  

    // If they match, hash the password  
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);  

    // Prepare the SQL statement to avoid SQL injection  
    $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");  
    $stmt->bind_param("sss", $username, $email, $hashed_password); // "sss" means three string parameters  

    // Execute the prepared statement  
    if ($stmt->execute() === TRUE) {  
        header("Location: ../login.html");  
        exit();  
    } else {  
        echo "Error: " . $stmt->error;  
    }  

    // Close the statement  
    $stmt->close();  
}  

$conn->close();  
?>