<?php  
session_start();  
session_destroy(); // Destroy the session  
echo json_encode(['status' => 'success']); // Send back a success response  
?>